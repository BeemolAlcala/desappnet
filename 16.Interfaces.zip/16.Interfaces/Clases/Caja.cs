namespace Interfaces.Clases{
    public class Caja : ICaja
    {
        public string Color { get ; set ; }
        public bool EstaAbierta { get; set; }
        public string Contenido { get; set ; }


         public Caja(){
        
        }

        public Caja(string color, bool estaAbierta, string contenido)
        {
            Color = color;
            EstaAbierta = estaAbierta;
            Contenido = contenido;
        }

        public void Abrir()
        {
            if(!EstaAbierta){
                EstaAbierta =true;
            } 
        }

        public void Cerrar()
        {
            if(EstaAbierta){
                EstaAbierta=false;
            }
        }
    }
}